from .ptype import Typer,TypeChain

class Typing:
    def __init__(self,semiotic) -> None:
        self.typer = Typer()