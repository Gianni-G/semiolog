from .pclass import Classifier,ClassChain

class Classifier:
    def __init__(self,semiotic) -> None:
        self.typer = Typer()