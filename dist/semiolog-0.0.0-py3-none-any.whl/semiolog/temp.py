from time import sleep
def wait_out(chain):
    sleep(1)
    print(chain[0])
    return chain